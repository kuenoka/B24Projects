//
//  Constants.swift
//  GCD_OPQ
//
//  Created by Oluwafemi Adenaike on 7/21/20.
//  Copyright © 2020 Oluwafemi Adenaike. All rights reserved.
//

import Foundation
let stringUrl1 = "https://thumbs.dreamstime.com/z/pink-tulips-flowers-background-card-mothers-day-march-happy-easter-waiting-spring-greeting-wedding-invitation-flat-lay-141125540.jpg"

let stringUrl2 = "https://thumbs.dreamstime.com/z/art-spring-flowers-background-frame-52852938.jpg"

let stringUrl3 = "https://thumbs.dreamstime.com/z/tulips-flowers-spring-mother-s-day-wooden-board-copyspace-your-own-text-50366822.jpg"

let stringUrl4 = "https://thumbs.dreamstime.com/z/red-tulips-spring-blooming-30853493.jpg"
let Notification_DataReceived = "Notification_DataReceived"
