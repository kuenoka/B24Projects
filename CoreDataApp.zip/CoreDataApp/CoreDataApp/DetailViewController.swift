//
//  DetailViewController.swift
//  CoreDataApp
//
//  Created by Oluwafemi Adenaike on 7/23/20.
//  Copyright © 2020 Oluwafemi Adenaike. All rights reserved.
//

import UIKit

//protocol DetailViewControllerProtocol {
//  func didCompleteSavingData()
//}

class DetailViewController: UIViewController {
  
  @IBOutlet weak var txtField: UITextField!
  @IBOutlet weak var addressTextField: UITextField!
  //var delegate: DetailViewControllerProtocol?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }
  
  @IBAction func saveData(_ sender: UIButton) {
    if txtField.text?.count == 0 {
      return
    }
    let name = txtField.text
    let address = addressTextField.text
    let p = Person.init(context: AppDelegate.appD.getViewContext())
    let addressDB = Address.init(context: AppDelegate.appD.getViewContext())
    addressDB.street = address
    p.name = name
    p.address = addressDB
    AppDelegate.appD.saveContext()
    dismiss(animated: true){
      //self.delegate?.didCompleteSavingData()
    }
  }
  
}
