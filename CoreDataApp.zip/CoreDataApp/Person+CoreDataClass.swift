//
//  Person+CoreDataClass.swift
//  CoreDataApp
//
//  Created by Oluwafemi Adenaike on 7/24/20.
//  Copyright © 2020 Oluwafemi Adenaike. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}
