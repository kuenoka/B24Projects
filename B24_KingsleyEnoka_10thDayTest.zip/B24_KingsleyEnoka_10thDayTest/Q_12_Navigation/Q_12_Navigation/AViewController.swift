//
//  AViewController.swift
//  Q_12_Navigation
//
//  Created by Oluwafemi Adenaike on 7/16/20.
//  Copyright © 2020 Oluwafemi Adenaike. All rights reserved.
//

import UIKit

class AViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
  @IBAction func cancel(_ sender: UIButton) {
    dismiss(animated: true) {
      
    }
  }
  
}
